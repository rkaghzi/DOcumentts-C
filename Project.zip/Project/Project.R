install.packages('ggplot2')
install.packages('gridExtra') 
install.packages("stringi")


library(ggplot2)
library(gridExtra)  
library(stringi)
library(reshape2)

#--------------------------------Task-1-------------------------------------
# Read data from CSV file
performance <- read.csv("D:/4th Semester/Probability and Statistics/Project/Student_Performance.csv", header = TRUE)
str(performance)
#--------------------------------Task-2-------------------------------------


# Remove the 1st, 2nd, and 4th columns
wallmart <- wallmart[, -c(1, 2, 4)]


# Calculate summary statistics of mode
getMode <- function(x) 
{
  ux <- unique(x)               #taking unique values
  ux[which.max(tabulate(match(x, ux)))]              #getting the maximum of unique values
}

# Calculate summary statistics
summary_ratings <- sapply(wallmart, function(x) 
{
  c(Mean = mean(x), Median = median(x), Mode = getMode(x), Quartiles = quantile(x))
})

#Printing Summary Of Mean, Median, Mode and Quartiles:
print(summary_ratings)

#--------------------------------Task-3-------------------------------------
# Reshape data for plotting
wallmart_long <- reshape2::melt(wallmart)



# Construct Box and Whisker Plot
num_colors <- length(unique(wallmart_long$variable))
color_palette <- c("blue", "green", "red", "purple", "orange", "yellow", "pink", "cyan", "magenta", "brown")[1:num_colors]

box_plot <- ggplot(wallmart_long, aes(x = variable, y = value, fill = variable)) +
  geom_boxplot(color = "black") +
  scale_fill_manual(values = color_palette) +
  theme_minimal() +
  labs(title = "Box and Whisker Plot of Wallmart Variables",
       x = "Variables",
       y = "Values")

# Print the box plot
print(box_plot)



# Rename columns to remove spaces and special characters
colnames(wallmart) <- c("Temperature", "Fuel_Price", "CPI", "Unemployment", "Weekly_Sales")

# Define function to calculate correlation and description
calculate_correlation <- function(x, y) {
  correlation <- cor(x, y)
  if (correlation > 0.5) {
    point_color <- "green"  # High correlation
    correlation_desc <- "High correlation"
  } else if (correlation > 0) {
    point_color <- "blue"  # Moderate correlation
    correlation_desc <- "Moderate correlation"
  } else {
    point_color <- "red"  # Low or negative correlation
    correlation_desc <- "Low or negative correlation"
  }
  return(list(correlation = correlation, color = point_color, description = correlation_desc))
}

# Calculate correlations and descriptions for scatter plots
temperature_sales_correlation <- calculate_correlation(wallmart$Temperature, wallmart$Weekly_Sales)
fuel_price_sales_correlation <- calculate_correlation(wallmart$Fuel_Price, wallmart$Weekly_Sales)
cpi_sales_correlation <- calculate_correlation(wallmart$CPI, wallmart$Weekly_Sales)
unemployment_sales_correlation <- calculate_correlation(wallmart$Unemployment, wallmart$Weekly_Sales)






