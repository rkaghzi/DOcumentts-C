
library(ggplot2)
library(gridExtra)  

# Step 1: Read data from CSV file
students_data <- read.csv("D:/4th Semester/Probability and Statistics/Project/Student_Performance.csv", header = TRUE)
str(students_data)

# Step 2: Remove the first index column if it exists
students_data <- students_data[, -3]

# Step 3: Calculate summary statistics excluding mode
getMode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

# Step 4: Calculate summary statistics
summary_stats <- sapply(students_data, function(x) {
  c(Mean = mean(x), Median = median(x), Mode = getMode(x), Quartiles = quantile(x))
})

# Step 5: Print the summary statistics
print(summary_stats)

# Step 4: Reshape data for plotting
students_data_long <- reshape2::melt(students_data[, -3])

# Step 5: Construct Box and Whisker Plot
box_plot <- ggplot(students_data_long, aes(x = variable, y = value, fill = variable)) +
  geom_boxplot(color = "black") +
  scale_fill_manual(values = c("skyblue", "grey", "yellow", "purple", "orange")) +
  theme_minimal() +
  labs(title = "Box and Whisker Plot of Student Performance Variables",
       x = "Variables",
       y = "Values")

# Print the box plot
print(box_plot)

# Step 4: Rename columns to remove spaces and special characters
colnames(students_data) <- c("Hours_Studied", "Previous_Scores", "Sleep_Hours", "Sample_Question_Papers", "Performance_Index")

# Step 6: Define function to calculate correlation and description
calculate_correlation <- function(x, y) {
  correlation <- cor(x, y)
  if (correlation > 0.5) {
    point_color <- "green"  # High correlation
    correlation_desc <- "High correlation"
  } else if (correlation > 0) {
    point_color <- "blue"  # Moderate correlation
    correlation_desc <- "Moderate correlation"
  } else {
    point_color <- "red"  # Low or negative correlation
    correlation_desc <- "Low or negative correlation"
  }
  return(list(correlation = correlation, color = point_color, description = correlation_desc))
}

# Step 7: Calculate correlations and descriptions for scatter plots
hours_studied_corr <- calculate_correlation(students_data$Hours_Studied, students_data$Performance_Index)
previous_scores_corr <- calculate_correlation(students_data$Previous_Scores, students_data$Performance_Index)
sleep_hours_corr <- calculate_correlation(students_data$Sleep_Hours, students_data$Performance_Index)
sample_papers_corr <- calculate_correlation(students_data$Sample_Question_Papers, students_data$Performance_Index)

# Step 8: Construct Scatter Plots
scatter_plot_hours <- ggplot(students_data, aes(x = Hours_Studied, y = Performance_Index)) +
  geom_point(color = hours_studied_corr$color) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  labs(title = "Hours Studied vs. Performance Index",
       x = "Hours Studied",
       y = "Performance Index",
       subtitle = paste("Correlation:", hours_studied_corr$correlation, hours_studied_corr$description)) +
  theme_minimal()

scatter_plot_scores <- ggplot(students_data, aes(x = Previous_Scores, y = Performance_Index)) +
  geom_point(color = previous_scores_corr$color) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  labs(title = "Previous Scores vs. Performance Index",
       x = "Previous Scores",
       y = "Performance Index",
       subtitle = paste("Correlation:", previous_scores_corr$correlation, previous_scores_corr$description)) +
  theme_minimal()

scatter_plot_sleep <- ggplot(students_data, aes(x = Sleep_Hours, y = Performance_Index)) +
  geom_point(color = sleep_hours_corr$color) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  labs(title = "Sleep Hours vs. Performance Index",
       x = "Sleep Hours",
       y = "Performance Index",
       subtitle = paste("Correlation:", sleep_hours_corr$correlation, sleep_hours_corr$description)) +
  theme_minimal()

scatter_plot_papers <- ggplot(students_data, aes(x = Sample_Question_Papers, y = Performance_Index)) +
  geom_point(color = sample_papers_corr$color) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  labs(title = "Sample Question Papers vs. Performance Index",
       x = "Sample Question Papers",
       y = "Performance Index",
       subtitle = paste("Correlation:", sample_papers_corr$correlation, sample_papers_corr$description)) +
  theme_minimal()

# Arrange scatter plots in a grid
grid.arrange(scatter_plot_hours, scatter_plot_scores, scatter_plot_sleep, scatter_plot_papers, nrow = 2)

# Perform initial linear regression
initial_model <- lm(Performance_Index ~ Hours_Studied + Previous_Scores + Sleep_Hours + Sample_Question_Papers, data = students_data)
initial_model 

summary(initial_model)
# Check the significance of variables
summary_initial <- summary(initial_model)

# Identify insignificant variables
insignificant_variables <- names(summary_initial$coefficients[,"Pr(>|t|)"][summary_initial$coefficients[,"Pr(>|t|)"] > 0.05])

# Replace insignificant variables with new significant variables
# For demonstration purposes, let's say we have new significant variables
Hours_Studied <- students_data$Previous_Scores * 2

# Fit a new regression model with significant variables
new_model <- lm(Performance_Index ~ Hours_Studied, data = students_data)

# Print the summary of the new model
summary(new_model)
