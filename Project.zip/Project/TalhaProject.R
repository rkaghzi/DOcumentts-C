library(ggplot2)
library(gridExtra)  
                                     #Task 1
# Step 1: Read data from CSV file
advertising_data <- read.csv("C:/Users/DELL/Desktop/Fi/Advertising Budget and Sales.csv", header = TRUE)
str(advertising_data)
                                     #Task 2
# Step 2: Remove the first index column if it exists
advertising_data <- advertising_data[, -1]
# Step 3: Calculate summary statistics excluding mode
getMode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}
# Step 4: Calculate summary statistics
summary_stats <- sapply(advertising_data, function(x) {
  c(Mean = mean(x), Median = median(x), Mode = getMode(x), Quartiles = quantile(x))
})
# Step 5: Print the summary statistics
print(summary_stats)
                                  #Task 3
# Step 4: Reshape data for plotting
advertising_data_long <- reshape2::melt(advertising_data)
# Step 5: Construct Box and Whisker Plot
box_plot <- ggplot(advertising_data_long, aes(x = variable, y = value, fill = variable)) +
  geom_boxplot(color = "black") +
  scale_fill_manual(values = c("blue", "green", "red", "purple")) +
  theme_minimal() +
  labs(title = "Box and Whisker Plot of Advertising Variables",
       x = "Variables",
       y = "Values")
# Print the box plot
print(box_plot)
                                 #Task 4
# Step 4: Rename columns to remove spaces and special characters
colnames(advertising_data) <- c("TV_Ad_Budget", "Radio_Ad_Budget", "Newspaper_Ad_Budget", "Sales")
# Step 6: Define function to calculate correlation and description
calculate_correlation <- function(x, y) {
  correlation <- cor(x, y)
  if (correlation > 0.5) {
    point_color <- "green"  # High correlation
    correlation_desc <- "High correlation"
  } else if (correlation > 0) {
    point_color <- "blue"  # Moderate correlation
    correlation_desc <- "Moderate correlation"
  } else {
    point_color <- "red"  # Low or negative correlation
    correlation_desc <- "Low or negative correlation"
  }
  return(list(correlation = correlation, color = point_color, description = correlation_desc))
}

# Step 7: Calculate correlations and descriptions for scatter plots
tv_sales_correlation <- calculate_correlation(advertising_data$TV_Ad_Budget, advertising_data$Sales)
radio_sales_correlation <- calculate_correlation(advertising_data$Radio_Ad_Budget, advertising_data$Sales)
newspaper_sales_correlation <- calculate_correlation(advertising_data$Newspaper_Ad_Budget, advertising_data$Sales)

# Step 8: Construct Scatter Plots
scatter_plot_tv <- ggplot(advertising_data, aes(x = TV_Ad_Budget, y = Sales)) +
  geom_point(color = tv_sales_correlation$color) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  labs(title = "TV Ad Budget vs. Sales",
       x = "TV Ad Budget ($)",
       y = "Sales ($)",
       subtitle = paste("Correlation:", tv_sales_correlation$correlation, tv_sales_correlation$description)) +
  theme_minimal()

scatter_plot_radio <- ggplot(advertising_data, aes(x = Radio_Ad_Budget, y = Sales)) +
  geom_point(color = radio_sales_correlation$color) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  labs(title = "Radio Ad Budget vs. Sales",
       x = "Radio Ad Budget ($)",
       y = "Sales ($)",
       subtitle = paste("Correlation:", radio_sales_correlation$correlation, radio_sales_correlation$description)) +
  theme_minimal()

scatter_plot_newspaper <- ggplot(advertising_data, aes(x = Newspaper_Ad_Budget, y = Sales)) +
  geom_point(color = newspaper_sales_correlation$color) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  labs(title = "Newspaper Ad Budget vs. Sales",
       x = "Newspaper Ad Budget ($)",
       y = "Sales ($)",
       subtitle = paste("Correlation:", newspaper_sales_correlation$correlation, newspaper_sales_correlation$description)) +
  theme_minimal()

# Arrange scatter plots in a grid
grid.arrange(scatter_plot_tv, scatter_plot_radio, scatter_plot_newspaper, nrow = 1)
# Scatterplot Matrix
# Scatterplot Matrix with different colors
pairs(advertising_data, col = c("blue", "green", "red", "purple"))
correlation_matrix <- cor(advertising_data)
print(correlation_matrix)

                             #Taask 5
# Step 4: Perform initial linear regression
initial_model <- lm(Sales ~ TV_Ad_Budget + Radio_Ad_Budget + Newspaper_Ad_Budget, data = advertising_data)
# Step 5: Check the significance of variables
summary_initial <- summary(initial_model)
summary(initial_model)
# Step 6: Identify insignificant variables
insignificant_variables <- names(summary_initial$coefficients[,"Pr(>|t|)"][summary_initial$coefficients[,"Pr(>|t|)"] > 0.05])
# Step 7: Replace insignificant variables with new significant variables
# For demonstration purposes, let's say we have new significant variables
Radio_Ad_Budget <- advertising_data$TV_Ad_Budget * 2
# Step 8: Fit a new regression model with significant variables
new_model <- lm(Sales ~ Radio_Ad_Budget, data = advertising_data)
# Step 9: Print the summary of the new model
summary(new_model)
